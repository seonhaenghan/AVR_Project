/*
 * RC_CAR.c
 *
 * Created: 2022-08-18 오전 9:50:40
 * Author : kccistc
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h> // printf, scanf 등이 정의 되어 있다.
#include <string.h> // strcpy, strcat, strcmp 등이 들어 있음

extern void bt_command_processing();
extern void init_UART1();
extern void UART0_transmit(uint8_t data);
extern int stopwatch_state; // stop_satch.c 에 들어 있다.


extern void pc_command_processing();
extern int get_BUTTON1();
extern int get_BUTTON2();
extern int get_BUTTON3();
extern void inc_stopwatch_clock(void);
extern void init_BUTTON();
extern void init_uart0();
extern void stopwatch_stop();
extern void init_led();


// 1. FOR printf
FILE OUTPUT = FDEV_SETUP_STREAM(UART0_transmit, NULL, _FDEV_SETUP_WRITE);



uint32_t ms_count=0;		// ms를 측정
uint32_t sec_count=0;
uint32_t ms_count2=0;		// sec를 측정
uint32_t del = 0;
uint32_t funcyc = 0;
void init_timer0();

volatile int count12 = 0;
volatile int state = 0;
volatile int state1 = 0;


// portb.0 : 500ms on/off
// portb.1 : 300ms on/off
// 1. 분주 : 64분주  ==>  16000000 / 64 = 250000Hz
// 2. T 계산 ==>  1/f = 1/250000 = 0.000004sec (4us)
// 3. 8 bit Timer OV : 4us * 256 = 1.024ms
// 256개의 pulse 를 count 하면 이곳으로 온다
//

ISR(TIMER0_OVF_vect) // 인터럽트 루틴을 길게 짤 수록 output delay가 증가하여 원하는 시간에 출력이 나오지 않음
{
	TCNT0 = 6; // TCNT를 6~256 == > 정확히 1ms 를 유지하기 위해
	// TINT 0 OVF INT
	ms_count++;
	ms_count2++;
	
	del = 300; // delay ms 변수 300ms
	if(ms_count2 % del == 0)
	{
		
		funcyc++;
	}
	
	if (ms_count >= 1000)   // 1000ms ==> 1sec
	{
		ms_count=0;
		sec_count++;    // sec counter 증가
		
	}	
	
}

int main(void)
{
	
	init_led();
	init_BUTTON();
	init_uart0(); // UART0를 초기화 한다.
	init_UART1(); // UART1 initial
	stdout = &OUTPUT; // for printf /fprintf(stdout, "test"); ==> printf stdin : 입력
	init_timer0();
	sei();			 // global interrupt 활성화
	
	while (1)
	{
		pc_command_processing(); 
		//bt_command_processing(); 
	}
}

void init_timer0()
{
	TCNT0 = 6;
	
	DDRF = 0x01 + 0x02 + 0x04;
	
	PORTF |= 0x02;
	
	TCCR0 |= (1 << CS02) | (0 << CS01) | (0 << CS00);  //  분주비를 64로 설정
	
	TIMSK |= (1 << TOIE0);
	
	
}



