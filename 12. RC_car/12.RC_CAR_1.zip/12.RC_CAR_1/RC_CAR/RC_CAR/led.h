﻿/*
 * led.h
 *
 * Created: 2022-08-09 오후 2:39:58
 *  Author: kccistc
 */ 


#ifndef LED_H_
#define LED_H_
void init_led();
void ledalltoggle(void);
void flower_on(void);
void f_off(void);
void shiftrightholdledon(void);
void shiftleftholdledon(void);
void shiftrightledon(void);
void shiftleftledon(void);


#endif /* LED_H_ */