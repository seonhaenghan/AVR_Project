/*
 * RC_CAR.c
 *
 * Created: 2022-08-18 오전 9:50:40
 * Author : kccistc
 */ 

/*
	1. LEFT MOTOR
		PORTF.0 : IN1
		PORTF.1 : IN2
	2. RIGHT MOTOR
		PORTF.2 : IN3
		PORTF.3 : IN4 
		IN1.IN3 IN2.IN4 
		======  ======
		   0       1    : 역회전
		   1       0    : 정회전
		   1       1    : STOP
*/

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h> // printf, scanf 등이 정의 되어 있다.
#include <string.h> // strcpy, strcat, strcmp 등이 들어 있음

#define MOTOR_DRIVER_PORT PORTF
#define MOTOR_DRIVER_PORT_DDR DDRF

#define MOTOR_DDR DDRB
#define MOTOR_RIGHT_PORT_DDR PB5 // OC1A
#define MOTOR_LEFT_PORT_DDR PB6  // OC1B

extern void bt_command_processing();
extern void init_UART1();
extern void UART0_transmit(uint8_t data);
extern void pc_command_processing();
extern int get_BUTTON1();
extern void init_BUTTON();
extern void init_uart0();
extern void init_led();


// 1. FOR printf
FILE OUTPUT = FDEV_SETUP_STREAM(UART0_transmit, NULL, _FDEV_SETUP_WRITE);



uint32_t ms_count=0;		// ms를 측정
uint32_t sec_count=0;
uint32_t ms_count2=0;		// sec를 측정

void init_timer0();
void init_pwm_motor(void);
void manual_mode_run(void);

volatile int state = 0;
volatile int state1 = 0;


// portb.0 : 500ms on/off
// portb.1 : 300ms on/off
// 1. 분주 : 64분주  ==>  16000000 / 64 = 250000Hz
// 2. T 계산 ==>  1/f = 1/250000 = 0.000004sec (4us)
// 3. 8 bit Timer OV : 4us * 256 = 1.024ms
// 256개의 pulse 를 count 하면 이곳으로 온다
//

ISR(TIMER0_OVF_vect) // 인터럽트 루틴을 길게 짤 수록 output delay가 증가하여 원하는 시간에 출력이 나오지 않음
{
	TCNT0 = 6; // TCNT를 6~256 == > 정확히 1ms 를 유지하기 위해
	// TINT 0 OVF INT
	ms_count++;
	
	if (ms_count >= 1000)   // 1000ms ==> 1sec
	{
		ms_count=0;
		sec_count++;    // sec counter 증가
		
	}	
	
}

int main(void)
{
	
	init_led();
	init_BUTTON();
	init_uart0(); // UART0를 초기화 한다.
	init_UART1(); // UART1 initial
	init_timer0();
	init_pwm_motor();
	
	
	stdout = &OUTPUT; // for printf /fprintf(stdout, "test"); ==> printf stdin : 입력
	sei();			 // global interrupt 활성화
	
	while (1)
	{
		manual_mode_run();
	
	}
}
extern volatile unsigned char UART1_RX_data;
void manual_mode_run(void)
{
	switch(UART1_RX_data)
	{
		case 'F' :

		forward(500);	// // 4us * 500 = 0.002sec (2ms)
printf("forward\n");
		break;
		
		case 'B' :

		backward(500);
printf("backward\n");
		break;
		
		case 'L' :

		turn_left(700);
printf("turn_L\n");
		break;
		
		case 'R' :
		turn_right(700);
printf("turn_R\n");
		break;
		
		case 'S' :
		stop(); 
printf("stop\n"); 
		break;
		
		default:
		break;
	}
}

void forward(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)); // Reset
	MOTOR_DRIVER_PORT |= (1 << 2) | (1 << 0);						   // 전진모드로 Setting (1010)
	
	OCR1A = speed;	// PB5 PWM 출력 left
	OCR1B = speed;	// PB6 PWM 출력	right 
	
}

void backward(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)); // Reset
	MOTOR_DRIVER_PORT |= (1 << 3) | (1 << 1);						   // 후진모드로 set (0101)
	
	OCR1A = speed;	// PB5 PWM 출력 left
	OCR1B = speed;	// PB6 PWM 출력	right
	
}

void turn_left(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)); // Reset
	MOTOR_DRIVER_PORT |= (1 << 2) | (1 << 0);						   // 전진모드로 Setting (1010)
	
	OCR1A = 0;		// PB5 PWM 출력 left
	OCR1B = speed;	// PB6 PWM 출력	right
}

void turn_right(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)); // Reset
	MOTOR_DRIVER_PORT |= (1 << 2) | (1 << 0);						   // 전진모드로 Setting (1010)
	
	OCR1A = speed;	// PB5 PWM 출력 left
	OCR1B = 0;		// PB6 PWM 출력	right
}

void stop()
{
	OCR1A = 0;		// PB5 PWM 출력 left
	OCR1B = 0;		// PB6 PWM 출력	right
	
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)); // Reset
	MOTOR_DRIVER_PORT |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3);	   // stop mode
}




void init_pwm_motor(void)
{	
	MOTOR_DRIVER_PORT_DDR |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3);		// motor driver port 
	MOTOR_DDR |= (1 << MOTOR_RIGHT_PORT_DDR) | (1 << MOTOR_LEFT_PORT_DDR); // motor pwm port
	
	TCCR1B |= (0 << CS12) | (1 << CS11) | (1 << CS10); // 64 분주 
	// 16000000Hz / 64 = 250000 Hz (Timer1에 공급되는 Clock)
	// 256bit count ==> 1.02ms (펄스를 256개를 카운트 하면 1.02ms 소요)
	// 127 / 250000 ==> 0.5ms 
	// 0x3ff(1023) ==> 4ms Top값을 이와 같이 설정 시 모터는 최고속도로 동작함 
	
	
	TCCR1B |= (1 << WGM13) | (1 << WGM12); // 모드 14 고속 PWM ICR1
	TCCR1A |= (1 << WGM11) | (1 << WGM10); // 모드 14 고속 PWM ICR1
	TCCR1A |= (1 << COM1A1) | (0 << COM1A0); // 비반전 MODE 설정 : OCR 시 low TOP 시 high 
	TCCR1A |= (1 << COM1B1) | (0 << COM1B1); // R, L 이 분리되어 있기에 2개 선언 
	
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)); // Reset 
	MOTOR_DRIVER_PORT |= (1 << 2) | (1 << 0);						   // 전진모드로 Setting 
	ICR1 = 0x3ff; // 1023 ==> 4ms 
}

void init_timer0()
{
	TCNT0 = 6;
	
	DDRF = 0x01 + 0x02 + 0x04;
	
	PORTF |= 0x02;
	
	TCCR0 |= (1 << CS02) | (0 << CS01) | (0 << CS00);  //  분주비를 64로 설정
	
	TIMSK |= (1 << TOIE0);
	
	
}



